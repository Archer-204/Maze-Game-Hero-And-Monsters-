package UI;

import java.util.Scanner;
import Model.round;
import Model.Maze;

public class menu {

    static int len = 20; //maze length
    static int wid = 15; //maze wid
    static int power;//Record heroes gained powers
    static int alive;//Record the number of living monsters
    static Maze m = new Maze();//The original maze, no monsters, heroes and power
    static char[][] truemap = new char[wid][len];//maze without fog
    static char[][] fakemap = new char[wid][len];//Foggy maze
    static round r;//Control monsters, hero actions

    //Change the position of the hero in the map according to the wasd input
    //input is temp ,move(Determine whether to hit the wall),live(Determine whether the game should end)
    //no output but change truemap and fake map
    static void MoveHero(char temp, boolean move, boolean live) {
        move = r.move(temp);
        power = r.getNum_of_power();
        if (move) {
            truemap = equalto(r.getMaze());
            fakemap = equalto(sight(fakemap, r.getMaze()));
            printmeun(fakemap);
        } else if (!move) {
            live = checklive(r.getMaze());
            if (live)
                System.out.println("Invalid move: you cannot move through walls! ");
            else {
                truemap = equalto(r.getMaze());
                fakemap = equalto(sight(fakemap, r.getMaze()));
                printmeun(fakemap);
                System.out.println("I'm sorry, you have been eaten!");
            }
        }
    }
    //return class round.getGameover()
    static boolean checkWin(round r) {
        return (r.is_gamer_win() && !r.getGameover());
    }

    static boolean checklive(char[][] temp) {
        for (int i = 1; i < len - 1; i++) {
            for (int j = 1; j < wid - 1; j++) {
                if (temp[j][i] == 'X')
                    return false;
            }
        }
        return true;
    }


    //By comparing the map without fog after action and the map with fog without action, a map of fog after action is generated.
    static char[][] sight(char[][] fake, char[][] real) {
        char[][] temp = new char[wid][len];
        temp = equalto(fake);
        for (int i = 1; i < len - 1; i++) {
            for (int j = 1; j < wid - 1; j++) {
                if (fake[j][i] == '!')
                    temp[j][i] = '.';
                if (real[j][i] == '!')
                    temp[j][i] = '!';
                if (fake[j][i] == '@')
                    temp[j][i] = real[j][i];
                if (temp[j][i] == '$' && real[j][i] != '$')
                    temp[j][i] = real[j][i];
                if (real[j][i] == 'X')
                    temp[j][i] = 'X';
                if (real[j][i] == '$')
                    temp[j][i] = '$';
                if (real[j][i] == '@') {
                    temp[j][i] = '@';
                    //Check if the surrounding eight grids are foggy.
                    for (int m = j - 1; m < j + 2; m++) {
                        for (int n = i - 1; n < i + 2; n++) {
                            if (temp[m][n] == '.') {
                                temp[m][n] = real[m][n];
                            }
                        }
                    }
                }
            }
        }
        return temp;
    }

    //Pass the value of the array
    static char[][] equalto(char[][] maze) {
        char[][] temp = new char[wid][len];
        for (int i = 0; i < len; i++) {
            for (int j = 0; j < wid; j++) {
                temp[j][i] = maze[j][i];
            }
        }
        return temp;
    }

    //Check how many powers are on the map.
    static int checkpower(char[][] maze) {
        int temp = 1;
        for (int i = 1; i < len - 1; i++) {
            for (int j = 1; j < wid - 1; j++) {
                if (maze[j][i] == '$') {
                    temp--;
                }
            }
        }
        return temp;
    }

    //Replace all spaces and walls in the maze with fog.
    static char[][] changemap(final char[][] maze) {
        char[][] temp = new char[wid][len];
        temp = equalto(maze);
        for (int i = 1; i < len - 1; i++) {
            for (int j = 1; j < wid - 1; j++) {
                if (maze[j][i] == ' ' || maze[j][i] == '#') {
                    temp[j][i] = '.';
                }
            }
        }
        return temp;
    }

    //print char[][]
    static void printMaze(char[][] maze) {
        for (int i = 0; i < len; i++) {
            for (int j = 0; j < wid; j++) {
                System.out.print(maze[j][i] + " ");
            }
            System.out.println();
        }
    }
    //print title
    static void printmeun(char[][] maze) {
        for (int i = 0; i < 10; i++) {
            System.out.print("-");
        }
        System.out.println("\n" + " 2) Map Reveal");
        for (int i = 0; i < 10; i++) {
            System.out.print("-");
        }
        System.out.println();
        printMaze(maze);
        alive = r.get_num_of_monsters_need_to_kill();
        System.out.println("Total number of monsters to be killed: " + alive);
        System.out.println("Number of powers currently in possession: " + power);
        System.out.println("Number of monsters alive: " + alive);
    }
    //print help meun
    static void printHelp() {
        for (int i = 0; i < 15; i++) {
            System.out.print("-");
        }
        System.out.println("\n" + " 4) Help Menu");
        for (int i = 0; i < 15; i++) {
            System.out.print("-");
        }
        System.out.println();
        System.out.println("DIRECTIONS: ");
        System.out.println("      Kill 3 Monsters!");
        System.out.println("LEGEND: ");
        System.out.println("      #: Wall ");
        System.out.println("      @: You (a hero) ");
        System.out.println("      !: Monster ");
        System.out.println("      $: Power");
        System.out.println("      .: Unexplored space");
        System.out.println("MOVES: ");
        System.out.println("      Use W (up), A (left), S (down) and D (right) to move. ");
        System.out.println("      (You must press enter after each move).");
    }

    public static void main(String[] args) {

        m.maze();
        m.makeMaze();//Initialize the maze
        r = new round(m.getmaze());//Initialize the round


        alive = r.get_num_of_monsters_need_to_kill();
        power = checkpower(m.getmaze());
        for (int i = 0; i < 10; i++) {
            System.out.print("-");
        }
        System.out.println("\n" + " 1) Start ");
        for (int i = 0; i < 10; i++) {
            System.out.print("-");
        }
        System.out.println("\n" + "\n" + "DIRECTIONS: ");
        System.out.println("      Kill 3 Monsters! ");
        System.out.println("LEGEND: ");
        System.out.println("      #: Wall ");
        System.out.println("      @: You (a hero) ");
        System.out.println("      !: Monster ");
        System.out.println("      $: Power");
        System.out.println("      .: Unexplored space");
        System.out.println("MOVES: ");
        System.out.println("      Use W (up), A (left), S (down) and D (right) to move. ");
        System.out.println("      (You must press enter after each move).");
        System.out.println("\n" + "Maze:");


        truemap = equalto(r.getMaze());//Map without fog
        fakemap = equalto(changemap(truemap));//Map with fog
        fakemap = equalto(sight(fakemap, truemap));// cells adjacent to where the hero is are revealed in all 8 directions
        printMaze(fakemap);
        alive = r.get_num_of_monsters_need_to_kill();
        power = r.getNum_of_power();
        System.out.println("Total number of monsters to be killed: " + alive);
        System.out.println("Number of powers currently in possession: " + power);
        System.out.println("Number of monsters alive: " + alive);

        boolean tag = true;//The game ends when the tag is false
        while (tag) {
            System.out.println("Enter your move [WASD?]:");
            Scanner meum = new Scanner(System.in);
            char select = meum.next().charAt(0);
            if (select >= 'A' && select <= 'Z')//Convert uppercase letters to lowercase letters.
                select += 32;
            boolean move = true;//Determine whether to hit the wall
            boolean live = true;//Determine whether the game should end
            switch (select) {
                case '?':
                    printHelp();
                    break;
                case 'm':
                    printmeun(truemap);
                    break;
                case 'w':
                    MoveHero('W', move, live);
                    break;
                case 'a':
                    MoveHero('A', move, live);
                    break;
                case 's':
                    MoveHero('S', move, live);
                    break;
                case 'd':
                    MoveHero('D', move, live);
                    break;
                case 'c':
                    r.set_num_of_monsters_killed(2);
                default:
                    break;
            }
            if (checkWin(r)) {
                tag = false;
                System.out.println("You win!!!!");
            }
            if (r.getGameover()) {
                tag = false;
                System.out.println("I'm sorry, you have been eaten! ");
                break;
            }
        }
    }
}

