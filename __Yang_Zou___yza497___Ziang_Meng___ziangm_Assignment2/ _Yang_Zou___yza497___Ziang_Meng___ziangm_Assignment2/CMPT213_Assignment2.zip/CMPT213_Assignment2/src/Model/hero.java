//Group members: Ziang Meng (ziangm), Yang Zou (yza497)
package Model;

//The hero class("@") is designed to be the player, it has 5 private fields:
//private int x;
//private int y;
//private final char name='@';
//private int num_of_power;
//private int num_of_monsters_killed;
public class hero {
    //private fields:
    private int x; //the x coordinate
    private int y; //the y coordinate
    private final char name='@'; //representation of "hero" in the game.
    private int num_of_power; //#powers hero currently owned
    private int num_of_monsters_killed; //#monsters had killed

    //default constructor
    public hero(){
        x=1;
        y=1;
        num_of_power=0;
        num_of_monsters_killed=0;
    }

    //getters
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public char getName(){
        return this.name;
    }
    public int getNum_of_power(){
        return num_of_power;
    }
    public int get_num_of_monsters_killed(){
        return num_of_monsters_killed;
    }

    //setters
    public void setX(int x){
        this.x= x;
    }
    public void setY(int y){
        this.y=y;
    }
    public void setNum_of_monsters_killed(int num){
        num_of_monsters_killed=num;
    }

    //this function is called when hero gains a power, it increments the #power owned by hero.
    public void gain_power(){
        num_of_power=num_of_power+1;
    }

    //this function is called when hero gains a power, it decrements the #power owned by hero.
    public  void spend_power(){
        num_of_power=num_of_power-1;
    }
}
