//Group members: Ziang Meng (ziangm), Yang Zou (yza497)
package Model;

//This class is designed to be a one-time tool for killing monsters
//This "power" class has 3 private fields:
//private int x;
//private int y;
//private final char name='$';
public class power {
    private int x; //the x coordinate
    private int y; //the x coordinate
    private final char name='$'; //representation of "monster" in the game.

    //defalut constructor
    public power(){
        x=0;
        y=0;
    }

    //getters
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public char getName(){
        return this.name;
    }

    //setters
    public void setX(int x){
        this.x=x;
    }
    public void setY(int y){
        this.y=y;
    }
}
