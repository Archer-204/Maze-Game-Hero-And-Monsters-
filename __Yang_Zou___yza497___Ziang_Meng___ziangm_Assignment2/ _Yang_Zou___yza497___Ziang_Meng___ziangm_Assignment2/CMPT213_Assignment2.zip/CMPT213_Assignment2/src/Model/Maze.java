package Model;

import java.util.Stack;
import java.util.ArrayList;
import java.util.List;


public class Maze
{
    boolean[][] used=new boolean[20][15]; //Used to mark whether a cell has been visited
    char[][] maze=new char[20][15];
    Node curr=new Node(1,1);
    Node next=new Node(1,1);
    Stack<Node> path = new Stack<Node>(); //Record the stack of char[][] traversed

    class Node
    {
        int x;
        int y;
        public Node(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

    //Initialize the maze
    public void maze()
    {
        //The 13*18 grid inside the maze is a wall, but they can all be used.
        for(int i = 0; i < 20; i++)
        {
            for(int j = 0; j < 15; j++)
            {
                maze[i][j] = '#';
                used[i][j] = false;
            }
        }
        //(1, 1) The space is used to place heroes, which must be open and inaccessible.
        maze[1][1] = ' ';
        used[1][1] = true;

        //The outermost layer is the wall and is not accessible.
        for(int j = 0; j < 15; j++)
        {
            used[0][j]=true;
            used[19][j] = true;
        }
        for(int j = 0; j < 20; j++)
        {
            used[j][0]=true;
            used[j][14] = true;
        }
    }
    //return maze char[][]
    public char[][] getmaze()
    {
        char[][] temp;
        temp=new char[15][20];
        for(int i = 0; i < 20; i++)
        {
            for(int j = 0; j < 15; j++)
            {
                temp[j][i]= maze[i][j];
            }
        }
        return temp;
    }

    public void makeMaze()
    {
        path.push(curr); //Push the current grid to the stack
        while(!path.empty())
        {
            Node[] notUsed = notUsedNode(curr);//Find unvisited neighbors
            if(notUsed.length == 0)
            {
                curr = path.pop();//If the grid has no accessible adjacent grid, jump back to the previous stack
                continue;
            }
            int random = (int)(Math.random() * (notUsed.length));
            next = notUsed[random]; //Randomly select an adjacent cell
            path.push(next);
            used[next.x][next.y] = true;
            maze[next.x][next.y] = ' ';
            maze[(curr.x + next.x) / 2][(curr.y + next.y) / 2] = ' '; //Remove the wall between the current grid and the next one
            curr = next;

        }
        maze[18][1]=' ';
        maze[18][13]=' ';
        maze[18][3]=' ';
        maze[18][5]=' ';
        maze[18][7]=' ';
        maze[18][9]=' ';
        maze[18][11]=' ';
        randdelete();//Randomly delete grids to form circles.
    }

    ////Randomly delete grids to form circles.
    public void randdelete()
    {
        //Randomly delete 100 times
        for(int i=0;i<100;i++) {
            int y = 1 + (int) (Math.random() * (17 - 1 + 1));
            int x = 1 + (int) (Math.random() * (13 - 1 + 1));//Random coordinates are generated in 13*17 of the maze.
            int temp=0;
            //Search 8 grids around, if less than 6 walls, you can delete the wall.
            for(int m=y-1;m<y+2;m++){
                for(int n=x-1;n<x+2;n++) {
                    if(maze[m][n]==' ')
                    {
                        temp++;
                    }
                }
            }
            if(temp<=5)
            {
                maze[y][x]=' ';
            }
            //If there are no less than 6 walls, search again.
            else
            {
                i--;
            }
        }
        //Line 19 is different from others. In order to satisfy the 2*2 principle, only can be deleted  which upper grid (line 18) is wall.
        for(int i=0;i<6;i++) {
            int x = 3 + (int) (Math.random() * (11 - 1 + 1));
            int y = 18;
            if(maze[y-1][x]=='#')
            {
                maze[y][x]=' ';
            }
        }
    }

    public Node[] notUsedNode(Node node)
    {
        int[] temp = {-2,2};
        List<Node> list = new ArrayList<Node>();
        //Determine whether the grids of (x, y+2) and (x, y-2) have been visited, and if not, join the linked list.
        for(int i = 0; i < 2; i++)
        {
            int x = node.x ;
            int y = node.y + temp[i];
            if( x >= 0 && x < 20 && y >= 0 && y < 15)
            {
                if(!used[x][y])
                    list.add(new Node(x,y));
            }
        }
        //Determine whether the grids of (x+2, y) and (x-2, y) have been visited, and if not, join the linked list.
        for(int i = 0; i <2; i++)
        {
            int x = node.x + temp[i];
            int y = node.y ;
            if( x >= 0 && x < 20 && y >= 0 && y < 15)
            {
                if(!used[x][y])
                    list.add(new Node(x,y));
            }
        }
        //Convert the linked list to an array.
        Node[] NotUsed = new Node[list.size()];
        for(int i = 0; i < list.size(); i++)
        {
            NotUsed[i] = list.get(i);
        }
        return NotUsed;
    }
}
