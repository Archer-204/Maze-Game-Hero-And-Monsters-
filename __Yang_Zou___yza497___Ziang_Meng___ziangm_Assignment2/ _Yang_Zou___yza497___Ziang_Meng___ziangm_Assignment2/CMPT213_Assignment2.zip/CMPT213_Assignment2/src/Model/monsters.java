//Group members: Ziang Meng (ziangm), Yang Zou (yza497)
package Model;

//This monster class("!") is designed to be killed by hero object
//The "monster" class has 5 private fields:
//private int x;
//private int y;
//private final char name='!';
//private char pre_dir;
//private boolean isDead;
public class monsters {
    //private fields:
    private int x; //the x coordinate
    private int y; //the x coordinate
    private final char name='!'; //representation of "monster" in the game.
    private char pre_dir; //direction of the pre-step of monster
    private boolean isDead; //the state of monster

    //default constructor
    public monsters(){
        x=13;
        y=1;
        pre_dir='W';
        isDead=false;
    }

    //getters
    public char getPre_dir() {
        return pre_dir;
    }
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public char getName(){
        return this.name;
    }

    //setters
    public void setX(int xx){
        x=xx;
    }
    public void setY(int yy){
        y=yy;
    }
    public void setDeath(){
        isDead=true;
    }
    public void setPre_dir(char pre_dir) {
        this.pre_dir = pre_dir;
    }

    //this function checks if monster is dead, return 1 is dead, vise versa.
    public boolean death_of_monster(){
        return isDead;
    }
}
