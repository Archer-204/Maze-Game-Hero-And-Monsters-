//Group members: Ziang Meng (ziangm), Yang Zou (yza497)
package Model;

//This class is designed to control all 3 characters of the game: hero, three monsters, power.
//This "round" class has 5 private fields:
//private hero h;
//private monsters m1,m2,m3;
//private power p;
//private char[][] maze;
//private boolean game_over;
public class round {
    //private fields:
    private hero h; //The character which gamer contrals to play.
    private monsters m1,m2,m3; //The targets which gamer need to kill, monsters movws randomly.
    private power p; //The tool nsed to kill monster.
    private char[][] maze; //The battle field, all characters move through the maze.
    private boolean game_over; //used to contral the state of player

    //default constructor, initializes the game., creats a maze, a hero, three monsters in 4 corners of maze, and a randomly generated power.
    public round(char[][]ma){
        h=new hero();
        m1=new monsters();
        m2=new monsters();
        m3=new monsters();
        p=new power();

        maze=ma;
        game_over=false;
        h.setX(1);
        h.setY(1);
        m1.setX(13);
        m1.setY(1);
        m2.setX(1);
        m2.setY(18);
        m3.setX(13);
        m3.setY(18);
        maze[h.getX()][h.getY()]=h.getName();
        maze[m1.getX()][m1.getY()]=m1.getName();
        maze[m2.getX()][m2.getY()]=m2.getName();
        maze[m3.getX()][m3.getY()]=m3.getName();
        int[] empty_cell=get_empty_maze_cell();
        p.setX(empty_cell[0]);
        p.setY(empty_cell[1]);
        maze[p.getX()][p.getY()]=p.getName();
        //m1
        if(maze[m1.getX()][m1.getY()-1]!='#'){
            m1.setPre_dir('W');
        }
        else if(maze[m1.getX()-1][m1.getY()]!='#'){
            m1.setPre_dir('A');
        }
        else if(maze[m1.getX()][m1.getY()+1]!='#'){
            m1.setPre_dir('S');
        }
        else if(maze[m1.getX()+1][m1.getY()]!='#'){
            m1.setPre_dir('D');
        }
        //m2
        if(maze[m2.getX()][m2.getY()-1]!='#'){
            m2.setPre_dir('W');
        }
        else if(maze[m2.getX()-1][m2.getY()]!='#'){
            m2.setPre_dir('A');
        }
        else if(maze[m2.getX()][m2.getY()+1]!='#'){
            m2.setPre_dir('S');
        }
        else if(maze[m2.getX()+1][m2.getY()]!='#'){
            m2.setPre_dir('D');
        }
        //m3
        if(maze[m3.getX()][m3.getY()-1]!='#'){
            m3.setPre_dir('W');
        }
        else if(maze[m3.getX()-1][m3.getY()]!='#'){
            m3.setPre_dir('A');
        }
        else if(maze[m3.getX()][m3.getY()+1]!='#'){
            m3.setPre_dir('S');
        }
        else if(maze[m3.getX()+1][m3.getY()]!='#'){
            m3.setPre_dir('D');
        }

    }


    //getters:

    //get x and y coordinates of an empty maze cell.
    public int[] get_empty_maze_cell(){
        int[] temp=new int[2];
        while(true) {
            int y = 1 + (int) (Math.random() * (18 - 1 + 1));
            int x = 1 + (int) (Math.random() * (13 - 1 + 1));
            if (maze[x][y] == ' '||maze[x][y]=='!') {
                temp[0] = x;
                temp[1] = y;
                return temp;
            }
        }
    }
    //check if game is over, return 1 if game over
    public boolean getGameover(){
        return game_over;
    }
    //get a new maze
    public char[][] getMaze(){
        char[][] ch=new char [15][20];
        ch=maze;
        return ch;
    }

    //get #powers
    public int getNum_of_power(){
        return h.getNum_of_power();
    }
    //get #monsters need to kill
    public int get_num_of_monsters_need_to_kill(){
        return 3-h.get_num_of_monsters_killed();
    }

    //setter: set #monsters killed
    public void set_num_of_monsters_killed(int num){
        h.setNum_of_monsters_killed(num);
    }

    //randomly generate a power
    public void generate_power(){
        //maze[p.getX()][p.getY()]=' ';
        int[] temp=get_empty_maze_cell();
        p.setX(temp[0]);
        p.setY(temp[1]);
        maze[p.getX()][p.getY()]=p.getName();
    }

    //contral the movement of hero, return 1 if success, 0 if died or faild.
    public boolean hero_step(char dir){
        switch (dir){
            case 'W':
                if(maze[h.getX()][h.getY()-1]==' '){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()-1);
                    maze[h.getX()][h.getY()]=h.getName();
                    return true;
                }
                else if(maze[h.getX()][h.getY()-1]=='$'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()-1);
                    maze[h.getX()][h.getY()]='@';
                    h.gain_power();
                    generate_power();
                    return true;
                }
                else if(maze[h.getX()][h.getY()-1]=='!'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()-1);
                    if(h.getNum_of_power()>0){
                        // h.setY(h.getY()-1);
                        maze[h.getX()][h.getY()]=h.getName();
                        h.spend_power();
                        h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                        if(m1.getX()==h.getX() && m1.getY()==h.getY()){
                            m1.setDeath();
                        }
                        else if(m2.getX()==h.getX() && m2.getY()==h.getY()){
                            m2.setDeath();
                        }
                        else if(m3.getX()==h.getX() && m3.getY()==h.getY()){
                            m3.setDeath();
                        }
                        return true;
                    }
                    else {
                        game_over = true;
                        maze[h.getX()][h.getY()]='X';
                        return true;
                    }
                }
                else if(maze[h.getX()][h.getY()-1]=='#'){
                    return false;
                }
                break;
            case 'A':
                if(maze[h.getX()-1][h.getY()]==' '){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()-1);
                    maze[h.getX()][h.getY()]=h.getName();
                    return true;
                }
                else if(maze[h.getX()-1][h.getY()]=='$'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()-1);
                    maze[h.getX()][h.getY()]='@';
                    h.gain_power();
                    generate_power();
                    return true;
                }
                else if(maze[h.getX()-1][h.getY()]=='!'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()-1);
                    if(h.getNum_of_power()>0){
                        //h.setY(h.getY()-1);
                        maze[h.getX()][h.getY()]=h.getName();
                        h.spend_power();
                        h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                        if(m1.getX()==h.getX() && m1.getY()==h.getY()){
                            m1.setDeath();
                        }
                        else if(m2.getX()==h.getX() && m2.getY()==h.getY()){
                            m2.setDeath();
                        }
                        else if(m3.getX()==h.getX() && m3.getY()==h.getY()){
                            m3.setDeath();
                        }
                        return true;
                    }
                    else {
                        game_over = true;
                        maze[h.getX()][h.getY()]='X';
                        return true;
                    }
                }
                else if(maze[h.getX()-1][h.getY()]=='#'){
                    return false;
                }
                break;

            case 'S':
                if(maze[h.getX()][h.getY()+1]==' '){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()+1);
                    maze[h.getX()][h.getY()]=h.getName();
                    return true;
                }
                else if(maze[h.getX()][h.getY()+1]=='$'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()+1);
                    maze[h.getX()][h.getY()]='@';
                    h.gain_power();
                    generate_power();
                    return true;
                }
                else if(maze[h.getX()][h.getY()+1]=='!'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setY(h.getY()+1);
                    if(h.getNum_of_power()>0){
                        //h.setY(h.getY()-1);
                        maze[h.getX()][h.getY()]=h.getName();
                        h.spend_power();
                        h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                        if(m1.getX()==h.getX() && m1.getY()==h.getY()){
                            m1.setDeath();
                        }
                        else if(m2.getX()==h.getX() && m2.getY()==h.getY()){
                            m2.setDeath();
                        }
                        else if(m3.getX()==h.getX() && m3.getY()==h.getY()){
                            m3.setDeath();
                        }
                        return true;
                    }
                    else {
                        game_over = true;
                        maze[h.getX()][h.getY()]='X';
                        return true;
                    }
                }
                else if(maze[h.getX()][h.getY()+1]=='#'){
                    return false;
                }
                break;
            case 'D':
                if(maze[h.getX()+1][h.getY()]==' '){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()+1);
                    maze[h.getX()][h.getY()]=h.getName();
                    return true;
                }
                else if(maze[h.getX()+1][h.getY()]=='$'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()+1);
                    maze[h.getX()][h.getY()]='@';
                    h.gain_power();
                    generate_power();
                    return true;
                }
                else if(maze[h.getX()+1][h.getY()]=='!'){
                    maze[h.getX()][h.getY()]=' ';
                    h.setX(h.getX()+1);
                    if(h.getNum_of_power()>0){
                        //h.setY(h.getY()-1);
                        maze[h.getX()][h.getY()]=h.getName();
                        h.spend_power();
                        h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                        if(m1.getX()==h.getX() && m1.getY()==h.getY()){
                            m1.setDeath();
                        }
                        else if(m2.getX()==h.getX() && m2.getY()==h.getY()){
                            m2.setDeath();
                        }
                        else if(m3.getX()==h.getX() && m3.getY()==h.getY()){
                            m3.setDeath();
                        }
                        return true;
                    }
                    else {
                        game_over = true;
                        maze[h.getX()][h.getY()]='X';
                        return true;
                    }
                }
                else if(maze[h.getX()+1][h.getY()]=='#'){
                    return false;
                }
                break;
            default:
                return true;
        }
        return true;
    }

    //contral the live monsters to randomly move a cell
    public void monsters_step(){
        // monster1
        if(!m1.death_of_monster()) {
            //enable maze cell of current monster location before next move of monster
            if(p.getX()==m1.getX() && p.getY()==m1.getY()) {
                maze[m1.getX()][m1.getY()]='$';
            }
            else{
                maze[m1.getX()][m1.getY()]=' ';
            }
            char preDir=m1.getPre_dir();

            //let monster move along the previous direction. If faild, randomly chose another way.
            switch (preDir){
                case 'W':
                    if(maze[m1.getX()][m1.getY()-1]!='#'){
                        if(maze[m1.getX()][m1.getY()-1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m1.setDeath();
                            }
                            else{
                                m1.setY(m1.getY()-1);
                                maze[m1.getX()][m1.getY()]='X';
                                game_over=true;
                            }
                        }
                        else{
                            m1.setY(m1.getY()-1);
                            maze[m1.getX()][m1.getY()]=m1.getName();
                        }

                    }

                    //If monster is facing a wall, then randomly walk to another way.
                    else if(maze[m1.getX()][m1.getY()-1]=='#'){
                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'A'
                        if(random==1 && maze[m1.getX()-1][m1.getY()]!='#'){
                            if(maze[m1.getX()-1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX() - 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m1.getX()-1][m1.getY()]=='#'){
                            m1.setY(m1.getY()+1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('S');
                            }
                        }

                        // 'S'
                        else if(random==2 ){
                            if(maze[m1.getX()][m1.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY() + 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('S');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m1.getX()+1][m1.getY()]!='#'){
                            if(maze[m1.getX()+1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX() + 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m1.getX()+1][m1.getY()]=='#'){
                            m1.setY(m1.getY()+1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('S');
                            }
                        }

                    }
                    break;

                case 'A':
                    if(maze[m1.getX()-1][m1.getY()]!='#'){
                        if(maze[m1.getX()-1][m1.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m1.setDeath();
                            }
                            else{
                                m1.setX(m1.getX()-1);
                                maze[m1.getX()][m1.getY()]='X';
                                game_over=true;
                            }
                        }
                        else {
                            m1.setX(m1.getX() - 1);
                            maze[m1.getX()][m1.getY()] = m1.getName();
                        }
                    }
                    else if(maze[m1.getX()-1][m1.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m1.getX()][m1.getY()-1]!='#'){
                            if(maze[m1.getX()][m1.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY() - 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m1.getX()][m1.getY()-1]=='#'){
                            m1.setX(m1.getX()+1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('D');
                            }
                        }

                        // 'D'
                        else if(random==2 ){
                            if(maze[m1.getX()+1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX()+1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('D');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m1.getX()][m1.getY()+1]!='#'){
                            if(maze[m1.getX()][m1.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY() + 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m1.getX()][m1.getY()+1]=='#'){
                            m1.setX(m1.getX()+1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('D');
                            }
                        }

                    }
                    break;

                case 'S':
                    if(maze[m1.getX()][m1.getY()+1]!='#'){
                        if(maze[m1.getX()][m1.getY()+1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m1.setDeath();
                            }
                            else{
                                m1.setY(m1.getY()+1);
                                maze[m1.getX()][m1.getY()]='X';
                                game_over=true;
                            }
                        }
                        else {
                            m1.setY(m1.getY()+1);
                            maze[m1.getX()][m1.getY()] = m1.getName();
                        }
                    }
                    else if(maze[m1.getX()][m1.getY()+1]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m1.getX()-1][m1.getY()]!='#'){
                            if(maze[m1.getX()-1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX() - 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m1.getX()-1][m1.getY()]=='#'){
                            m1.setY(m1.getY()-1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('W');
                            }
                        }

                        // 'W'
                        else if(random==2 ){
                            if(maze[m1.getX()][m1.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY()-1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('W');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m1.getX()+1][m1.getY()]!='#'){
                            if(maze[m1.getX()+1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX() + 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m1.getX()+1][m1.getY()]=='#'){
                            m1.setY(m1.getY()-1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('D');
                            }
                        }

                    }
                    break;


                case 'D':
                    if(maze[m1.getX()+1][m1.getY()]!='#'){
                        if(maze[m1.getX()+1][m1.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m1.setDeath();
                            }
                            else{
                                m1.setX(m1.getX()+1);
                                maze[m1.getX()][m1.getY()]='X';
                                game_over=true;
                            }
                        }
                        else {
                            m1.setX(m1.getX() + 1);
                            maze[m1.getX()][m1.getY()] = m1.getName();
                        }
                    }
                    else if(maze[m1.getX()+1][m1.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m1.getX()][m1.getY()-1]!='#'){
                            if(maze[m1.getX()][m1.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY() - 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m1.getX()][m1.getY()-1]=='#'){
                            m1.setX(m1.getX()-1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('A');
                            }
                        }

                        // 'A'
                        else if(random==2 ){
                            if(maze[m1.getX()-1][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setX(m1.getX()-1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setX(m1.getX()-1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('A');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m1.getX()][m1.getY()+1]!='#'){
                            if(maze[m1.getX()][m1.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    m1.setY(m1.getY()+1);
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else {
                                m1.setY(m1.getY() + 1);
                                maze[m1.getX()][m1.getY()] = m1.getName();
                                m1.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m1.getX()][m1.getY()+1]=='#'){
                            m1.setX(m1.getX()-1);
                            if(maze[m1.getX()][m1.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m1.setDeath();
                                }
                                else{
                                    maze[m1.getX()][m1.getY()]='X';
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m1.getX()][m1.getY()]=m1.getName();
                                m1.setPre_dir('D');
                            }
                        }

                    }
                    break;
            }
        }

        // M2
        if(!m2.death_of_monster()){
            if(p.getX()==m2.getX() && p.getY()==m2.getY()) {
                maze[m2.getX()][m2.getY()]='$';
            }
            else{
                maze[m2.getX()][m2.getY()]=' ';
            }

            char preDir=m2.getPre_dir();
            switch (preDir){
                case 'W':
                    if(maze[m2.getX()][m2.getY()-1]!='#'){
                        if(maze[m2.getX()][m2.getY()-1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m2.setDeath();
                            }
                            else{
                                m2.setY(m2.getY()-1);
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m2.setY(m2.getY() - 1);
                            maze[m2.getX()][m2.getY()] = m2.getName();
                        }
                    }
                    else if(maze[m2.getX()][m2.getY()-1]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'A'
                        if(random==1 && maze[m2.getX()-1][m2.getY()]!='#'){
                            if(maze[m2.getX()-1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX() - 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m2.getX()-1][m2.getY()]=='#'){
                            m2.setY(m2.getY()+1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('S');
                            }
                        }

                        // 'S'
                        else if(random==2 ){
                            if(maze[m2.getX()][m2.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY() + 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('S');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m2.getX()+1][m2.getY()]!='#'){
                            if(maze[m2.getX()+1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX() + 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m2.getX()+1][m2.getY()]=='#'){
                            m2.setY(m2.getY()+1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('S');
                            }
                        }

                    }
                    break;

                case 'A':
                    if(maze[m2.getX()-1][m2.getY()]!='#'){
                        if(maze[m2.getX()-1][m2.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m2.setDeath();
                            }
                            else{
                                m2.setX(m2.getX()-1);
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m2.setX(m2.getX() - 1);
                            maze[m2.getX()][m2.getY()] = m2.getName();
                        }
                    }
                    else if(maze[m2.getX()-1][m2.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m2.getX()][m2.getY()-1]!='#'){
                            if(maze[m2.getX()][m2.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY() - 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m2.getX()][m2.getY()-1]=='#'){
                            m2.setX(m2.getX()+1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('D');
                            }
                        }

                        // 'D'
                        else if(random==2 ){
                            if(maze[m2.getX()+1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX()+1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('D');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m2.getX()][m2.getY()+1]!='#'){
                            if(maze[m2.getX()][m2.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY() + 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m2.getX()][m2.getY()+1]=='#'){
                            m2.setX(m2.getX()+1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('D');
                            }
                        }

                    }
                    break;

                case 'S':
                    if(maze[m2.getX()][m2.getY()+1]!='#'){
                        if(maze[m2.getX()][m2.getY()+1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m2.setDeath();
                            }
                            else{
                                m2.setY(m2.getY()+1);
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m2.setY(m2.getY()+1);
                            maze[m2.getX()][m2.getY()] = m2.getName();
                        }
                    }
                    else if(maze[m2.getX()][m2.getY()+1]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m2.getX()-1][m2.getY()]!='#'){
                            if(maze[m2.getX()-1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX() - 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m2.getX()-1][m2.getY()]=='#'){
                            m2.setY(m2.getY()-1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('W');
                            }
                        }

                        // 'W'
                        else if(random==2 ){
                            if(maze[m2.getX()][m2.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY()-1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('W');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m2.getX()+1][m2.getY()]!='#'){
                            if(maze[m2.getX()+1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX() + 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m2.getX()+1][m2.getY()]=='#'){
                            m2.setY(m2.getY()-1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('D');
                            }
                        }

                    }
                    break;


                case 'D':
                    if(maze[m2.getX()+1][m2.getY()]!='#'){
                        if(maze[m2.getX()+1][m2.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m2.setDeath();
                            }
                            else{
                                m2.setX(m2.getX()+1);
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m2.setX(m2.getX() + 1);
                            maze[m2.getX()][m2.getY()] = m2.getName();
                        }
                    }
                    else if(maze[m2.getX()+1][m2.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m2.getX()][m2.getY()-1]!='#'){
                            if(maze[m2.getX()][m2.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY() - 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m2.getX()][m2.getY()-1]=='#'){
                            m2.setX(m2.getX()-1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('A');
                            }
                        }

                        // 'A'
                        else if(random==2 ){
                            if(maze[m2.getX()-1][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setX(m2.getX()-1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setX(m2.getX()-1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('A');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m2.getX()][m2.getY()+1]!='#'){
                            if(maze[m2.getX()][m2.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    m2.setY(m2.getY()+1);
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m2.setY(m2.getY() + 1);
                                maze[m2.getX()][m2.getY()] = m2.getName();
                                m2.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m2.getX()][m2.getY()+1]=='#'){
                            m2.setX(m2.getX()-1);
                            if(maze[m2.getX()][m2.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m2.setDeath();
                                }
                                else{
                                    maze[m2.getX()][m2.getY()]=m2.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m2.getX()][m2.getY()]=m2.getName();
                                m2.setPre_dir('D');
                            }
                        }

                    }
                    break;
            }
        }

        // M3
        if(!m3.death_of_monster()){
            if(p.getX()==m3.getX() && p.getY()==m3.getY()) {
                maze[m3.getX()][m3.getY()]='$';
            }
            else{
                maze[m3.getX()][m3.getY()]=' ';
            }

            char preDir=m3.getPre_dir();
            switch (preDir){
                case 'W':
                    if(maze[m3.getX()][m3.getY()-1]!='#'){
                        if(maze[m3.getX()][m3.getY()-1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m3.setDeath();
                            }
                            else{
                                m3.setY(m3.getY()-1);
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m3.setY(m3.getY() - 1);
                            maze[m3.getX()][m3.getY()] = m3.getName();
                        }
                    }
                    else if(maze[m3.getX()][m3.getY()-1]=='#'){
                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'A'
                        if(random==1 && maze[m3.getX()-1][m3.getY()]!='#'){
                            if(maze[m3.getX()-1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX() - 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m3.getX()-1][m3.getY()]=='#'){
                            m3.setY(m3.getY()+1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('S');
                            }
                        }

                        // 'S'
                        else if(random==2 ){
                            if(maze[m3.getX()][m3.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY() + 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('S');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m3.getX()+1][m3.getY()]!='#'){
                            if(maze[m3.getX()+1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX() + 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m3.getX()+1][m3.getY()]=='#'){
                            m3.setY(m3.getY()+1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('S');
                            }
                        }

                    }
                    break;

                case 'A':
                    if(maze[m3.getX()-1][m3.getY()]!='#'){
                        if(maze[m3.getX()-1][m3.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m3.setDeath();
                            }
                            else{
                                m3.setX(m3.getX()-1);
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m3.setX(m3.getX() - 1);
                            maze[m3.getX()][m3.getY()] = m3.getName();
                        }
                    }
                    else if(maze[m3.getX()-1][m3.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m3.getX()][m3.getY()-1]!='#'){
                            if(maze[m3.getX()][m3.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY() - 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m3.getX()][m3.getY()-1]=='#'){
                            m3.setX(m3.getX()+1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('D');
                            }
                        }

                        // 'D'
                        else if(random==2 ){
                            if(maze[m3.getX()+1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX()+1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('D');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m3.getX()][m3.getY()+1]!='#'){
                            if(maze[m3.getX()][m3.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY() + 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m3.getX()][m3.getY()+1]=='#'){
                            m3.setX(m3.getX()+1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('D');
                            }
                        }

                    }
                    break;

                case 'S':
                    if(maze[m3.getX()][m3.getY()+1]!='#'){
                        if(maze[m3.getX()][m3.getY()+1]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m3.setDeath();
                            }
                            else{
                                m3.setY(m3.getY()+1);
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m3.setY(m3.getY()+1);
                            maze[m3.getX()][m3.getY()] = m3.getName();
                        }
                    }
                    else if(maze[m3.getX()][m3.getY()+1]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m3.getX()-1][m3.getY()]!='#'){
                            if(maze[m3.getX()-1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX() - 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('A');
                            }
                        }
                        else if(random==1 && maze[m3.getX()-1][m3.getY()]=='#'){
                            m3.setY(m3.getY()-1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('W');
                            }
                        }

                        // 'W'
                        else if(random==2 ){
                            if(maze[m3.getX()][m3.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY()-1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('W');
                            }
                        }

                        // 'D'
                        else if(random==3 && maze[m3.getX()+1][m3.getY()]!='#'){
                            if(maze[m3.getX()+1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX() + 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('D');
                            }
                        }
                        else if(random==3 && maze[m3.getX()+1][m3.getY()]=='#'){
                            m3.setY(m3.getY()-1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('D');
                            }
                        }

                    }
                    break;


                case 'D':
                    if(maze[m3.getX()+1][m3.getY()]!='#'){
                        if(maze[m3.getX()+1][m3.getY()]=='@'){
                            if(h.getNum_of_power()>0){
                                h.spend_power();
                                h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                m3.setDeath();
                            }
                            else{
                                m3.setX(m3.getX()+1);
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                game_over=true;
                            }
                        }
                        else {
                            m3.setX(m3.getX() + 1);
                            maze[m3.getX()][m3.getY()] = m3.getName();
                        }
                    }
                    else if(maze[m3.getX()+1][m3.getY()]=='#'){

                        double x = (int)(Math.random()*((3-1)+1))+1;
                        int random= (int) x;

                        //'W'
                        if(random==1 && maze[m3.getX()][m3.getY()-1]!='#'){
                            if(maze[m3.getX()][m3.getY()-1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY() - 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('W');
                            }
                        }
                        else if(random==1 && maze[m3.getX()][m3.getY()-1]=='#'){
                            m3.setX(m3.getX()-1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('A');
                            }
                        }

                        // 'A'
                        else if(random==2 ){
                            if(maze[m3.getX()-1][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setX(m3.getX()-1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setX(m3.getX()-1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('A');
                            }
                        }

                        // 'S'
                        else if(random==3 && maze[m3.getX()][m3.getY()+1]!='#'){
                            if(maze[m3.getX()][m3.getY()+1]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    m3.setY(m3.getY()+1);
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else {
                                m3.setY(m3.getY() + 1);
                                maze[m3.getX()][m3.getY()] = m3.getName();
                                m3.setPre_dir('S');
                            }
                        }
                        else if(random==3 && maze[m3.getX()][m3.getY()+1]=='#'){
                            m3.setX(m3.getX()-1);
                            if(maze[m3.getX()][m3.getY()]=='@'){
                                if(h.getNum_of_power()>0){
                                    h.spend_power();
                                    h.setNum_of_monsters_killed(h.get_num_of_monsters_killed()+1);
                                    m3.setDeath();
                                }
                                else{
                                    maze[m3.getX()][m3.getY()]=m3.getName();
                                    game_over=true;
                                }
                            }
                            else{
                                maze[m3.getX()][m3.getY()]=m3.getName();
                                m3.setPre_dir('D');
                            }
                        }

                    }
                    break;
            }
        }

    }

    //contral the movement of hero and monsters, return 0 if gameover.
    public boolean move(char dir){
        boolean result=hero_step(dir);
        if(game_over){
            return false;
        }
        monsters_step();
        return result;
    }

    //check if gamer is win, return 1 if win
    public boolean is_gamer_win(){
        if(h.get_num_of_monsters_killed()==3)
            return true;
        return game_over;
    }

}

